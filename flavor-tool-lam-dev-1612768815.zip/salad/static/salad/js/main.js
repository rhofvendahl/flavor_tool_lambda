$(document).ready(function() {
    var saladManager = new SaladManager();
    saladManager.load();
});
